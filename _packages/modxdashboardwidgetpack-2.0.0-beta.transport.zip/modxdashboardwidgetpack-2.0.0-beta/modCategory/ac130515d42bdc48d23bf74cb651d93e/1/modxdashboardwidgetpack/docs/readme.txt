---------------------------------------
MODXDashboardWidgetPack
---------------------------------------

MODXDashboardWidgetPack is a MODX Extra developed by Sterc.


Please view https://github.com/Sterc/modx-dashboard-widgets-pack for the readme.
