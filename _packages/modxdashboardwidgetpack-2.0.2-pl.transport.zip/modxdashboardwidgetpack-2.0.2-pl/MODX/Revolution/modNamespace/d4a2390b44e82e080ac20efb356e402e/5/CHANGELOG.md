Changelog for MODXDashboardWidgetPack.

MODXDashboardWidgetPack 2.0.2
==============
- MODX3 Refactor

MODXDashboardWidgetPack 2.0.1
==============
- Welcome widget css fix

MODXDashboardWidgetPack 2.0.0
==============
- MODX 3 compatibility

MODXDashboardWidgetPack 1.0.1
==============
- Removed unused plugin

MODXDashboardWidgetPack 1.0.0
==============
- Initial release.